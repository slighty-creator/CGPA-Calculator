// CGPA Calculator - semester GPA + cumulative CGPA
#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include <cctype>
using namespace std;

struct Course {
    string name;
    double credits;
    double points;
    char grade;
};

double gradeToPoints(char g) {
    switch (toupper(g)) {
        case 'A': return 4.0;
        case 'B': return 3.0;
        case 'C': return 2.0;
        case 'D': return 1.0;
        default:  return 0.0; // F
    }
}

int main() {
    int semesters;
    cout << "How many semesters? ";
    cin >> semesters;

    double totalCredits = 0, totalPoints = 0;

    for (int s = 1; s <= semesters; ++s) {
        int n;
        cout << "\n--- Semester " << s << " ---\nNumber of courses: ";
        cin >> n;

        vector<Course> courses;
        double semCredits = 0, semPoints = 0;

        for (int i = 1; i <= n; ++i) {
            Course c;
            cout << "Course " << i << " name: ";
            cin >> ws;
            getline(cin, c.name);
            cout << "Credit hours: ";
            cin >> c.credits;
            cout << "Grade (A/B/C/D/F): ";
            cin >> c.grade;
            c.points = gradeToPoints(c.grade) * c.credits;
            semCredits += c.credits;
            semPoints += c.points;
            courses.push_back(c);
        }

        cout << "\n" << left << setw(25) << "Course" << setw(10) << "Credits"
             << setw(8) << "Grade" << "Points\n";
        for (const auto& c : courses)
            cout << left << setw(25) << c.name << setw(10) << c.credits
                 << setw(8) << (char)toupper(c.grade) << c.points << "\n";

        double gpa = semCredits > 0 ? semPoints / semCredits : 0;
        cout << fixed << setprecision(2) << "Semester GPA: " << gpa << "\n";

        totalCredits += semCredits;
        totalPoints += semPoints;
    }

    double cgpa = totalCredits > 0 ? totalPoints / totalCredits : 0;
    cout << fixed << setprecision(2)
         << "\nTotal credits: " << totalCredits
         << "\nCGPA: " << cgpa << "\n";
    return 0;
}
