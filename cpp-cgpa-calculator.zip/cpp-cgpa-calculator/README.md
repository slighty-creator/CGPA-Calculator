# CGPA Calculator

Console CGPA calculator in C++: enter courses, credit hours and grades to get semester GPA and cumulative CGPA.

## Features
- Enter any number of semesters and courses
- Letter grades A-F converted to grade points
- Course-wise table with credits and points
- Semester GPA and overall CGPA

## C++ concepts used
- structs
- vectors
- switch statements
- formatted output (iomanip)

## Build and run
```bash
g++ -std=c++17 -Wall -Wextra main.cpp -o cgpa
./cgpa        # Windows: cgpa.exe
```

Requires a C++17 compiler (g++, clang++ or MSVC).

## Author
Muhammad Hassaan - DAE CIT student, GCT Attock.

_Project 01 of 20 in my beginner C++ projects series._
